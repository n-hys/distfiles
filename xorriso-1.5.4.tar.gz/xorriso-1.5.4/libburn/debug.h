/* -*- indent-tabs-mode: t; tab-width: 8; c-basic-offset: 8; -*- */

#ifndef BURN__DEBUG_H
#define BURN__DEBUG_H

void burn_print(int level, const char *a, ...);

#endif /* BURN__DEBUG_H */
